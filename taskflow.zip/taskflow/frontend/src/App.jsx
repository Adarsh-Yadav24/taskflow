import { useEffect, useMemo, useState } from "react";
import { api } from "./api";

const FILTERS = [
  { key: "all", label: "All" },
  { key: "open", label: "Open" },
  { key: "done", label: "Done" },
];

const PRIORITIES = [
  { key: "high", label: "High" },
  { key: "medium", label: "Medium" },
  { key: "low", label: "Low" },
];

const EMPTY_TEXT = {
  all: "No tasks yet. Type one above and press Add task.",
  open: "Nothing left to do. Nice.",
  done: "No finished tasks yet. Tick one off to see it here.",
};

function formatDue(iso) {
  if (!iso) return null;
  const d = new Date(`${iso}T00:00:00`);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const diff = Math.round((d - today) / 86400000);
  const label = d.toLocaleDateString(undefined, { day: "numeric", month: "short" });
  if (diff === 0) return { label: "Due today", overdue: false };
  if (diff === 1) return { label: "Due tomorrow", overdue: false };
  if (diff < 0) return { label: `Overdue, ${label}`, overdue: true };
  return { label: `Due ${label}`, overdue: false };
}

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("all");

  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState("medium");
  const [dueDate, setDueDate] = useState("");
  const [adding, setAdding] = useState(false);

  async function load() {
    setLoading(true);
    setError("");
    try {
      setTasks(await api.list());
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function addTask(e) {
    e.preventDefault();
    const clean = title.trim();
    if (!clean || adding) return;
    setAdding(true);
    setError("");
    try {
      const created = await api.create({
        title: clean,
        priority,
        due_date: dueDate || null,
      });
      setTasks((prev) => [created, ...prev]);
      setTitle("");
      setDueDate("");
    } catch (e) {
      setError(e.message);
    } finally {
      setAdding(false);
    }
  }

  async function toggle(task) {
    const next = !task.done;
    setTasks((prev) => prev.map((t) => (t.id === task.id ? { ...t, done: next } : t)));
    try {
      await api.update(task.id, { done: next });
    } catch (e) {
      setTasks((prev) => prev.map((t) => (t.id === task.id ? { ...t, done: task.done } : t)));
      setError(e.message);
    }
  }

  async function remove(task) {
    const snapshot = tasks;
    setTasks((prev) => prev.filter((t) => t.id !== task.id));
    try {
      await api.remove(task.id);
    } catch (e) {
      setTasks(snapshot);
      setError(e.message);
    }
  }

  const counts = useMemo(
    () => ({
      all: tasks.length,
      open: tasks.filter((t) => !t.done).length,
      done: tasks.filter((t) => t.done).length,
    }),
    [tasks]
  );

  const visible = useMemo(() => {
    if (filter === "open") return tasks.filter((t) => !t.done);
    if (filter === "done") return tasks.filter((t) => t.done);
    return tasks;
  }, [tasks, filter]);

  return (
    <main className="shell">
      <header className="top">
        <h1>TaskFlow</h1>
        <p className="tally">
          {counts.open} open, {counts.done} done
        </p>
      </header>

      <form className="composer" onSubmit={addTask}>
        <input
          className="title-input"
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="What needs doing?"
          maxLength={200}
          aria-label="Task title"
        />
        <div className="composer-row">
          <label className="field">
            <span>Priority</span>
            <select value={priority} onChange={(e) => setPriority(e.target.value)}>
              {PRIORITIES.map((p) => (
                <option key={p.key} value={p.key}>
                  {p.label}
                </option>
              ))}
            </select>
          </label>
          <label className="field">
            <span>Due date</span>
            <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
          </label>
          <button className="primary" type="submit" disabled={!title.trim() || adding}>
            {adding ? "Adding..." : "Add task"}
          </button>
        </div>
      </form>

      {error && (
        <div className="error" role="alert">
          <span>{error}</span>
          <button onClick={() => setError("")} aria-label="Dismiss error">
            Dismiss
          </button>
        </div>
      )}

      <div className="tabs" role="tablist" aria-label="Filter tasks">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            role="tab"
            aria-selected={filter === f.key}
            className={filter === f.key ? "tab active" : "tab"}
            onClick={() => setFilter(f.key)}
          >
            {f.label} <span className="count">{counts[f.key]}</span>
          </button>
        ))}
      </div>

      {loading ? (
        <p className="note">Loading tasks...</p>
      ) : visible.length === 0 ? (
        <p className="note">{EMPTY_TEXT[filter]}</p>
      ) : (
        <ul className="list">
          {visible.map((task) => {
            const due = formatDue(task.due_date);
            return (
              <li key={task.id} className={task.done ? "task done" : "task"} data-priority={task.priority}>
                <input
                  type="checkbox"
                  checked={task.done}
                  onChange={() => toggle(task)}
                  aria-label={`Mark "${task.title}" as ${task.done ? "open" : "done"}`}
                />
                <div className="body">
                  <span className="task-title">{task.title}</span>
                  <span className="meta">
                    <span className={`pill ${task.priority}`}>{task.priority}</span>
                    {due && (
                      <span className={due.overdue && !task.done ? "due overdue" : "due"}>
                        {due.label}
                      </span>
                    )}
                  </span>
                </div>
                <button className="delete" onClick={() => remove(task)} aria-label={`Delete "${task.title}"`}>
                  Delete
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </main>
  );
}
